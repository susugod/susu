/* 
* @Author: susu
* @Date:   2017-06-26 08:39:07
*/
document.writeln("<div class=\'bg\'>");
document.writeln("  <div class=\'header-wrap container\'>");
document.writeln("  <!-- 顶部 -->");
document.writeln("      <div class=\'header\'>");
document.writeln("         <div class=\'row\'>");
document.writeln("          <!-- logo -->");
document.writeln("            <div class=\'logo col-md-6\'>");
document.writeln("                <div class=\'logo\'>");
document.writeln("                    <a href=\'../app/index.html\'><img src=\'../ico/logo.png\'></a>");
document.writeln("                </div>");
document.writeln("                <div class=\'pad-left\'>");
document.writeln("                  <h3>团体心理辅导活动管理系统</h3>");
document.writeln("                  <h6>www.ttxlffdhdglxt.com.cn</h6>");
document.writeln("                </div>");
document.writeln("            </div>  ");
document.writeln("            <div class=\'col-md-6 row-r\'>  ");
document.writeln("                <!-- 搜索框 --> ");
document.writeln("                <div class=\'search\'>");
document.writeln("                    <input type=\'text\' class=\'form-control\' value=\'请输入活动名称\' />");
document.writeln("                    <img src=\'../ico/find.png\' class=\'search-pic\' alt=\'\' />");
document.writeln("                </div> ");
document.writeln("                <!-- 登陆 -->");
document.writeln("                <div class=\'submit\'><a href=\'../app/login.html\'>登陆</a></div>   ");
document.writeln("            </div>");
document.writeln("          </div>  ");
document.writeln("      </div>");
document.writeln("  </div>");
document.writeln("</div>");
document.writeln("<!-- 主导航栏  -->");
document.writeln("<nav class=\'navbar navbar-default\'>");
document.writeln("  <div class=\'container\'>");
document.writeln("    <div class=\'collapse navbar-collapse\' id=\'bs-example-navbar-collapse-1\'>");
document.writeln("      <ul class=\'nav navbar-nav\' id=\'navbar\'>");
document.writeln("        <li><a href=\'../app/index.html\'>首页</a></li> ");
document.writeln("        <li><a href=\'../actived-web/actived-fir.html\'>招募信息</a></li>");
document.writeln("        <li><a href=\'../ceping/ask-juan.html\'>测评调查</a></li> ");
document.writeln("        <li><a href=\'../ative-jilu/lu.html\'>活动记录</a></li>");
document.writeln("        <li><a href=\'../applay-state/applay-state.html\'>报名状态</a></li>");
document.writeln("        <li><a href=\'../ge/base.html\'>个人中心</a></li>");
document.writeln("      </ul>");
document.writeln("    </div>");
document.writeln("  </div>");
document.writeln("</nav>");
